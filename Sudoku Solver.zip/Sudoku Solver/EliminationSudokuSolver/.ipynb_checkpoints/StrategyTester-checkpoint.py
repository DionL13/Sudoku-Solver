import numpy as np
import unittest

import RemovePossVals 
import OnlyVal
import Naked
import Hidden 

class TestSolvingStrategies:

    def setUp(self):
        '''
        Sets up an empty board for each test
        '''
        
        # Initialises a board and poss_vals as attributes for every class object
        self.board = np.zeros(9,9)
        self.poss_vals = [[list(range(1,10)) for _ in range(9)] for _ in range(9)]

    # Defining functions to test RemovePossVals functions

    def test_RemovePossVals_pointing(self, i, j, val)

        # Testing set-up
        self.board[i][j] = [val]

        # Running RemovePossVals.col
        RemovePossVals.pointing(j, val, self.poss_vals, self.board)
       
        assert poss_vals_col[0] == i, "RemovePossVal.pointing() Not Working" # Prints Assertion Error if condition is false
            





    

